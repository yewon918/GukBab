package pos2;

public class POS_Main {
	public static void main(String[] args) {
		new POS_Frame();
	}
}
